import os
secret_key = os.urandom(24)
print("UR SRT KEY IS" ,secret_key)